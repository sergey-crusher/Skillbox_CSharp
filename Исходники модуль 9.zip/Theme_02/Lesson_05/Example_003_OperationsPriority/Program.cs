﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_003_OperationsPriority
{
    class Program
    {
        static void Main(string[] args)
        {

            // 
            // Унарные операции
            // Префиксный инкремент
            // %, /, * 
            // +, -
            // Постфиксный инкремент
            // () - скобки меняют приоритет операций
            //

            Console.WriteLine((2+2)*2);


        }
    }
}
