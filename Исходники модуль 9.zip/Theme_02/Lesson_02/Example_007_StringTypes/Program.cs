﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_007_StringTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Тип данных string используется для хранения строковых констант.
            // Они обрамляются двойными кавычками. 

            string word = "Привет!";
            word = "Привет, мир!";

            // Замечание
            // Продвинутые возможности использования этого типа в уроке 
            // "Файлы"


        }
    }
}
