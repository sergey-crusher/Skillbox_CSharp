﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_824_Queue
{
    class Program
    {
        static void Main(string[] args)
        {

            // Обходы графа в ширину,
            // Алгоритм Дейкстры
            // Алгоритмы раскраски

        }
    }
}
